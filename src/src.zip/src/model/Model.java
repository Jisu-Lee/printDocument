package model;

public class Model {
    private String depart;
    private String posit;
    private String name;
    private String content;//야근내용
    private static String memo;//특이사항
    private String time = "-";//야근하는 시간
    private static String date;//야근하는 날짜
    private static int num;//야근하는 사람의 수
    private boolean isChecked=false;

    public Model(){}

    public Model(String depart, String posit, String name, String content, String memo, String date, String time, int num, boolean isChecked){
        this.depart=depart;
        this.posit=posit;
        this.name=name;
        this.content=content;
        this.memo=memo;
        this.date=date;
        this.time=time;
        this.num=num;
        this.isChecked=isChecked;
    }

    public String getDepart() {
        return depart;
    }

    public void setDepart(String depart) {
        this.depart = depart;
    }

    public String getPosit() {
        return posit;
    }

    public void setPosit(String posit) {
        this.posit = posit;
    }

    public String getName(){return name;}

    public void setName(String name){this.name=name;}

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getDate(){return date;}

    public void setDate(String date){this.date=date;}

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public boolean getIsChecked(){return isChecked;}

    public void setIsChecked(boolean isChecked){this.isChecked=isChecked;}
}

