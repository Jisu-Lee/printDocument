package view;

import controller.Controller;
import controller.Wordfile;
import javafx.application.Platform;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Callback;
import model.Model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class View {
    TableView<Model> table;
    Controller controller;

    public View(Stage primaryStage){
        controller = new Controller();
        Model model = new Model();

        primaryStage.setTitle("야근 신청 프로그램");
        try {
            primaryStage.getIcons().add(new Image(new FileInputStream("./icon.png")));
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }

        //add BorderPane
        BorderPane border = new BorderPane();

        //add HBox
        HBox hbox = new HBox(8);
        hbox.setPadding(new Insets(15,12,15,12));

        Label dateLabel = new Label("근무예정일 :");
        dateLabel.setStyle("-fx-font-size: 14px;");
        dateLabel.setTextAlignment(TextAlignment.CENTER);
        DatePicker datepicker = new DatePicker();
        datepicker.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                LocalDate date = datepicker.getValue();
                model.setDate(date.format(DateTimeFormatter.ISO_LOCAL_DATE));

            }
        });


        Label instruction = new Label("업무내용 기입 후 엔터를 눌러주세요.");
        instruction.setStyle("-fx-text-fill: #fd2f2d; -fx-line-spacing: 3px;-fx-font-size: 14px;");
        instruction.setTextAlignment(TextAlignment.CENTER);
        instruction.setPadding(new Insets(13, 0, 0, 290));

        hbox.getChildren().addAll(dateLabel, datepicker, instruction);

        //add table
        table = new TableView<>();
       // table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        table.setEditable(true);
        //table.setPadding(new Insets(10, 15, 10, 15));
        table.getFocusModel().focusedCellProperty().addListener(
                ( ObservableValue<? extends TablePosition> observable, TablePosition oldValue, TablePosition newValue ) ->
                {
                    if ( newValue != null )
                    {
                        Platform.runLater( () ->
                        {
                            table.edit( newValue.getRow(), newValue.getTableColumn() );
                        } );
                    }
                }
        );
        //Checkbox Column
        TableColumn checkCol = new TableColumn("야근자");
        checkCol.setMinWidth(50);
        checkCol.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Model, Boolean>, ObservableValue>() {
            @Override
            public ObservableValue call(TableColumn.CellDataFeatures<Model, Boolean> param) {
                Model model = param.getValue();
                SimpleBooleanProperty booleanprop = new SimpleBooleanProperty(model.getIsChecked());

                booleanprop.addListener(new ChangeListener<Boolean>() {
                    @Override
                    public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                        model.setIsChecked(newValue);
                        System.out.println(controller.getModelList().get(0).getIsChecked());
                        //System.out.println(newValue);
                    }
                });
                return booleanprop;
            }
        });
        checkCol.setCellFactory(new Callback<TableColumn<Model, Boolean>, TableCell<Model, Boolean>>() {
            @Override
            public TableCell<Model, Boolean> call(TableColumn<Model, Boolean> param) {
                CheckBoxTableCell<Model, Boolean> cell = new CheckBoxTableCell<Model, Boolean>();
                cell.setAlignment(Pos.CENTER);
                return cell;
            }
        });

        //Name Column
        TableColumn<Model, String> nameCol = new TableColumn<>("성명");
        nameCol.setMinWidth(100);
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        //Department Column
        TableColumn<Model, String> departCol = new TableColumn<>("부서");
        departCol.setMinWidth(200);
        departCol.setCellValueFactory(new PropertyValueFactory<>("depart"));

        //Position Column
        TableColumn<Model, String> positCol = new TableColumn<>("직위");
        positCol.setMinWidth(150);
        positCol.setCellValueFactory(new PropertyValueFactory<>("posit"));

        //Content Column
        TableColumn contentCol = new TableColumn("업무내용");
        contentCol.setPrefWidth(350);
        contentCol.setCellFactory(TextFieldTableCell.forTableColumn());
        contentCol.setOnEditCommit(
                new EventHandler<TableColumn.CellEditEvent<Model, String>>() {
                    @Override
                    public void handle(TableColumn.CellEditEvent<Model, String> e) {
                        Model model = e.getRowValue();
                        model.setContent(e.getNewValue());
                        System.out.println(controller.getModelList().get(0).getContent());
                        System.out.println(e.getNewValue());
                    }
                }
        );

        //Time column
        TableColumn timeCol = new TableColumn("근무종료시간");
        timeCol.setMinWidth(150);
        ObservableList<String> timeList = controller.getTime();
        timeCol.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Model, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue call(TableColumn.CellDataFeatures<Model, String> param) {
                Model model = param.getValue();
                String time = model.getTime();
                return new SimpleStringProperty(time);
            }
        });
        timeCol.setCellFactory(ComboBoxTableCell.forTableColumn(timeList));
        timeCol.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Model, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Model, String> event) {
                ((Model) event.getTableView().getItems().get(event.getTablePosition().getRow())).setTime(event.getNewValue());
                System.out.println(controller.getModelList().get(0).getTime());
                System.out.println(event.getNewValue());
            }
        });

        //add all columns to table
        try {
            table.setItems(controller.getData());
        }catch(IOException e){
            System.out.println("error reading data");
        }
        table.getColumns().addAll(checkCol, nameCol, departCol, positCol, contentCol, timeCol);

        //add VBox
        VBox vbox = new VBox(8);
        vbox.setPadding(new Insets(15,10,15,10));

        Label memoLabel = new Label("특이사항");
        TextArea memoText = new TextArea();
        memoText.setPrefHeight(100);

        AnchorPane anchorPane = new AnchorPane();
        Button nextBtn = new Button("다음 >");
        nextBtn.setStyle("-fx-font-weight: bold; -fx-font-size: 16px");
        nextBtn.setPrefSize(100, 50);
        nextBtn.setOnAction(t -> {
            model.setMemo(memoText.getText());
            try {
                Wordfile wordfile=new Wordfile(controller.getModelList());
                wordfile.insertInfo();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                Wordfile wordfile=new Wordfile(controller.getModelList());
                wordfile.insertInfo();
                wordfile.ConvertToImage();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            ConfirmBox.display(primaryStage, controller);
        });

        anchorPane.getChildren().add(nextBtn);
        AnchorPane.setRightAnchor(nextBtn, 5d);

        vbox.getChildren().addAll(memoLabel, memoText, anchorPane);


        //add layouts to borderPane
        border.setTop(hbox);
        border.setCenter(table);
        border.setBottom(vbox);

        //add borderPane to scene
        Scene scene = new Scene(border, 1008, 650);

        primaryStage.setScene(scene);
        primaryStage.show();
    }


}
