package view;

import controller.Controller;
import controller.Main;
import controller.PrintFile;
import controller.Wordfile;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javax.print.PrintException;
import javax.print.PrintService;
import javax.xml.soap.Text;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ConfirmBox {

    public static void display(Stage primaryStage, Controller controller){
        Stage window = new Stage();
        final PrintFile[] printFile = new PrintFile[1];
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("야근 신청 프로그램 - 출력물 확인");
        try {
            window.getIcons().add(new Image(new FileInputStream("./icon.png")));
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }

        BorderPane border = new BorderPane();
        StackPane stackL = new StackPane();
        //left side
        try {
            Image image = new Image(new FileInputStream("./output.jpeg"));
            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(650);
            imageView.setPreserveRatio(true);
            //imageView.setSmooth(true)
            stackL.getChildren().add(imageView);
            stackL.setAlignment(Pos.CENTER);
            stackL.setPadding(new Insets(15, 15, 15, 15));
        }catch(FileNotFoundException e){
            System.err.println("err : " + e);
        }
        border.setCenter(stackL);

        //right side
        StackPane stackR = new StackPane();
        VBox vbox = new VBox(25);
        //print button
        Button printBtn = new Button("출력");
        printBtn.setPrefSize(150, 50);
        printBtn.setOnAction(t -> {
            try {
                printFile[0] =new PrintFile();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (PrintException e) {
                e.printStackTrace();
            }
        });
        //edit button
        Button editBtn = new Button("수정");
        editBtn.setPrefSize(150, 50);
        editBtn.setOnAction(e -> window.close());
        //exit button
        Button exitBtn = new Button("프로그램\n종료");
        exitBtn.setPrefSize(150, 80);
        exitBtn.setOnAction(e -> {
            window.close();
            primaryStage.close();
        });
        exitBtn.setTextAlignment(TextAlignment.CENTER);

        //button style
        printBtn.setStyle("-fx-font-size: 18px;");
        editBtn.setStyle("-fx-font-size: 18px;");
        exitBtn.setStyle("-fx-font-size: 18px;");

        //vbox layout
        vbox.getChildren().addAll(printBtn, editBtn, exitBtn);
        vbox.setPadding(new Insets(15, 50, 15, 15));
        vbox.setAlignment(Pos.CENTER);

        stackR.getChildren().add(vbox);
        stackR.setAlignment(Pos.CENTER);
        border.setRight(vbox);

        Scene scene = new Scene(border, 1000, 1000);
        window.setScene(scene);
        window.showAndWait();
    }
}
