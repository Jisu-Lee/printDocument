
package controller;

import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import java.awt.print.PrinterJob;
import java.io.FileInputStream;
import java.io.IOException;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.MediaSizeName;

public class PrintFile {

    public PrintFile() throws IOException, PrintException {
        PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
        pras.add(new Copies(1));//Samsung printer로 출력
        pras.add(MediaSizeName.ISO_A4);
        PrintService pss[] = PrintServiceLookup.lookupPrintServices(DocFlavor.INPUT_STREAM.JPEG, pras);
        if (pss.length == 0)
            throw new RuntimeException("No printer services available.");
        PrintService ps = findPrintService("Samsung ML-2850 Series PCL6");
        System.out.println("Printing to " + ps);

        DocPrintJob job = ps.createPrintJob();
        FileInputStream fin = new FileInputStream("output.jpeg");
        Doc doc = new SimpleDoc(fin, DocFlavor.INPUT_STREAM.JPEG, null);
        job.print(doc, pras);
        fin.close();
    }

    public static PrintService findPrintService(String printerName) {
        printerName = printerName.toLowerCase();

        PrintService service = null;

        // Get array of all print services
        PrintService[] services = PrinterJob.lookupPrintServices();

        // Retrieve a print service from the array
        for (int index = 0; service == null && index < services.length; index++) {

            if (services[index].getName().toLowerCase().indexOf(printerName) >= 0) {
                service = services[index];
            }
        }

        // Return the print service
        return service;
    }

}
