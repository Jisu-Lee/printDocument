package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Model;

import javax.print.PrintService;
import java.io.IOException;
import java.util.List;

public class Controller {
    List<Model> modelList;
    ObservableList<Model> data;

    public Controller(){
        data = FXCollections.observableArrayList();
        ExcelReader exreader=new controller.ExcelReader();
        try {
            modelList = exreader.getModelList();
        }catch(IOException e){
            System.out.println("error reading excel data");
        }
        for(int i=0; i<modelList.size(); i++){
            data.add(modelList.get(i));
        }

    }
    public ObservableList<Model> getData() throws IOException { return data; }

    public List<Model> getModelList(){ return modelList; }

    public ObservableList<String> getTime(){
        ObservableList<String> time = FXCollections.observableArrayList(
                "18:30",
                "19:00",
                "19:30",
                "20:00",
                "20:30",
                "21:00",
                "21:30",
                "22:00"
        );
        return time;
    }

}
