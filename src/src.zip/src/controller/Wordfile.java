package controller;

import java.io.*;
import java.util.List;

import com.mswordtoimage.MsWordToImageConvert;
import model.Model;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;

public class Wordfile {

    private Model model;
    private List <Model> models;
    private String filename;
    private FileOutputStream out;
    private XWPFDocument doc;
    private List<XWPFTable> table;

    public Wordfile(List<Model> list) throws IOException {
        filename = "word_file.docx";
        out = new FileOutputStream("create_table.docx");
        doc = new XWPFDocument(new FileInputStream(filename));
        table = doc.getTables();
        models=list;
    }

    public void insertInfo() throws Exception {

        int tableNum = 0;
        int peopleNum=0;
        //model.getNum()=peopleNum;

        for (XWPFTable xwpfTable : table) { // table의 값들이 xwpfTable로 들어간다.
            tableNum++;//num은 table의 수

            if (tableNum == 2) {//두번째에 있는 table의 내용 추출
                model=new Model();
                model=models.get(0);
                xwpfTable.getRow(0).getCell(0).setText(model.getDate());//날짜

                for (int i = 0; i < models.size(); i++) {
                    model=models.get(i);
                    if(model.getIsChecked()) {
                        peopleNum++;
                        xwpfTable.getRow(1 + peopleNum).getCell(0).setText(model.getDepart());
                        xwpfTable.getRow(1 + peopleNum).getCell(1).setText(model.getPosit());
                        xwpfTable.getRow(1 + peopleNum).getCell(2).setText(model.getName());
                        xwpfTable.getRow(1 + peopleNum).getCell(3).setText(model.getContent());
                        xwpfTable.getRow(1 + peopleNum).getCell(4).setText(model.getTime());
                    }
                }
                xwpfTable.getRow(11).getCell(0).setText(model.getMemo());

                doc.write(out);
                out.close();
                System.out.println("docx written successfully");
            }
        }
    }

    public void ConvertToImage() throws IOException {

        MsWordToImageConvert convert = new MsWordToImageConvert("7157428137", "5462154439184074171099156");
        convert.fromFile("create_table.docx");
        try {
            convert.toFile("output.jpeg");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}