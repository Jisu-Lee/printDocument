
package controller;

import model.Model;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExcelReader {
public List<Model> getModelList() throws IOException {

        List<Model> modelList=new ArrayList<Model>();
        FileInputStream fis=null;
        XSSFWorkbook workbook=null;
        //String excelname="조직도.xlsx";

        try{
        fis=new FileInputStream("조직도.xlsx");
        workbook=new XSSFWorkbook(fis);

        XSSFSheet curSheet;
        XSSFRow curRow;
        XSSFCell curCell;
        Model model;

        for(int sheetIndex=0; sheetIndex<workbook.getNumberOfSheets(); sheetIndex++){
        curSheet=workbook.getSheetAt(sheetIndex);

        for(int rowIndex=0; rowIndex<curSheet.getPhysicalNumberOfRows(); rowIndex++){
        if(rowIndex!=0) {
        curRow = curSheet.getRow(rowIndex);
        model = new Model();
        String value;

        //row의 첫번째 cell값이 비어있지 않은 경우에만 cell 탐색
        if(!"".equals(curRow.getCell(0).getStringCellValue())){
        for(int cellIndex=0; cellIndex<curRow.getPhysicalNumberOfCells(); cellIndex++){
        curCell=curRow.getCell(cellIndex);

        value=curCell.getStringCellValue();

        switch(cellIndex){
        case 0:
        model.setDepart(value); break;
        case 1:
        model.setPosit(value);break;
        case 2:
        model.setName(value);break;
default:
        break;
        }
        }
        }
        modelList.add(model);
        }
        }
        }

        } catch (FileNotFoundException e) {
        e.printStackTrace();
        } catch (IOException e) {
        e.printStackTrace();
        } finally{
        workbook.close();
        fis.close();
        }
        return modelList;
        }

public void printModelList() throws IOException {
        controller.ExcelReader exreader=new controller.ExcelReader();
        List<Model> xlsxList=exreader.getModelList();
        Model model;

        for(int i=0; i<xlsxList.size(); i++){
        model=xlsxList.get(i);
        System.out.println(model.getDepart()+model.getPosit()+model.getName());
        }
        }
        }