package controller;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import model.Model;
import view.View;

import java.io.IOException;
import java.util.List;

public class Main extends Application{
    View view;
    Model model;

    public static void main(String[] args) throws IOException {
       launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        View view = new View(primaryStage);
    }

}
